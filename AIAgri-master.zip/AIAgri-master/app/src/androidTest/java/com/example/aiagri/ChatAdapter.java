package com.example.aiagri;

public class ChatAdapter {
}
